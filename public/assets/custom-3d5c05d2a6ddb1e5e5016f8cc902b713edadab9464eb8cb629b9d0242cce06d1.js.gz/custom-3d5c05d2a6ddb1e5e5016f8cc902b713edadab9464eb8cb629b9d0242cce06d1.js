$(document).ready(function () {

  // help change user controller to handle captured payments for signin
  // help add tag_id to captured payments in signin and signup and in the forms

  var url = window.location,
      global_page_params = PageParameter.get_params(),
      chart_labels = [], chart_totals = [], chart_txns = [],
      contact_url = '/contact_forms.json', searchNumBtn = $('#searchNumberBtn');


  $.ajaxSetup({ cache:false });

  // bootstrap -select plugin
  $('#signupForm .selectpicker').selectpicker({
      mobile: true,
      width: "inherit"
  });
  $('#merchantProfile .selectpicker').selectpicker({
      mobile: true
  });
  // bootstrap -select plugin


  // validate signin form
  $('#signinForm')
      .formValidation({
          // I am validating Bootstrap form
          framework: 'bootstrap',
          live: 'disabled',

          // Feedback icons
          /*icon: {
              valid: 'fa fa-check',
              invalid: 'fa fa-times',
              validating: 'fa fa-refresh'
          },*/

          // List of fields and their validation rules
          fields: {
              'user[email]': {
                  verbose: false,
                  validators: {
                      notEmpty: {
                          message: 'Your email is required'
                      },
                      emailAddress: {
                          message: "The email isn't valid"
                      },
                      /*remote: {
                          type: 'GET',
                          url: 'https://api.mailgun.net/v2/address/validate?callback=?',
                          crossDomain: true,
                          name: 'address',
                          data: {
                              // Registry a Mailgun account and get a free API key
                              // at https://mailgun.com/signup
                              api_key: 'pubkey-83a6-sl6j2m3daneyobi87b3-ksx3q29'
                          },
                          dataType: 'jsonp',
                          validKey: 'is_valid',
                          message: "The email isn't valid"
                      }*/
                  }
              },
              'user[password]': {
                  validators: {
                      notEmpty: {
                          message: 'Your password is required'
                      }
                  }
              }
          }
      })
      .on('success.validator.fv', function(e, data) {
          if (data.field === 'email' && data.validator === 'remote') {
              var response = data.result;  // response is the result returned by MailGun API
              if (response.did_you_mean) {
                  // Update the message
                  data.element                    // The field element
                      .data('fv.messages')        // The message container
                      .find('[data-fv-validator="remote"][data-fv-for="email"]')
                      .html('Did you mean ' + response.did_you_mean + '?')
                      .show();
              }
          }
      })
      .on('err.validator.fv', function(e, data) {
          if (data.field === 'email' && data.validator === 'remote') {
              // We need to reset the error message
              data.element                // The field element
                  .data('fv.messages')    // The message container
                  .find('[data-fv-validator="remote"][data-fv-for="email"]')
                  .html("The email isn't valid")
                  .show();
          }
      })
      .on('success.form.fv', function(e, data) {
          set_hidden_fields();
      });
  ////


  // validate forgot password form
  $('#ForgotPassword')
      .formValidation({
          // I am validating Bootstrap form
          framework: 'bootstrap',
          live: 'disabled',
          // List of fields and their validation rules
          fields: {
              'user[email]': {
                  verbose: false,
                  row: '.group',
                  validators: {
                      notEmpty: {
                          message: 'Your email is required'
                      },
                      emailAddress: {
                          message: "The email isn't valid"
                      },
                      remote: {
                          type: 'GET',
                          url: 'https://api.mailgun.net/v2/address/validate?callback=?',
                          crossDomain: true,
                          name: 'address',
                          data: {
                              // Registry a Mailgun account and get a free API key
                              // at https://mailgun.com/signup
                              api_key: 'pubkey-83a6-sl6j2m3daneyobi87b3-ksx3q29'
                          },
                          dataType: 'jsonp',
                          validKey: 'is_valid',
                          message: "The email isn't valid"
                      }
                  }
              }
          }
      })
      .on('success.validator.fv', function(e, data) {
          if (data.field === 'email' && data.validator === 'remote') {
              var response = data.result;  // response is the result returned by MailGun API
              if (response.did_you_mean) {
                  // Update the message
                  data.element                    // The field element
                      .data('fv.messages')        // The message container
                      .find('[data-fv-validator="remote"][data-fv-for="email"]')
                      .html('Did you mean ' + response.did_you_mean + '?')
                      .show();
              }
          }
      })
      .on('err.validator.fv', function(e, data) {
          if (data.field === 'email' && data.validator === 'remote') {
              // We need to reset the error message
              data.element                // The field element
                  .data('fv.messages')    // The message container
                  .find('[data-fv-validator="remote"][data-fv-for="email"]')
                  .html("The email isn't valid")
                  .show();
          }
      });
  // validate forgot password form


  // user profile forms
  $('#user-profile-form')
      .formValidation({
          // I am validating Bootstrap form
          framework: 'bootstrap',
          live: 'disabled',

          // List of fields and their validation rules!
          fields: {
              'user[email]': {
                  verbose: false,
                  row: '.group',
                  validators: {
                      notEmpty: {
                          message: 'Your email is required'
                      },
                      emailAddress: {
                          message: "The email isn't valid"
                      },
                      remote: {
                          type: 'GET',
                          url: 'https://api.mailgun.net/v2/address/validate?callback=?',
                          crossDomain: true,
                          name: 'address',
                          data: {
                              // Registry a Mailgun account and get a free API key
                              // at https://mailgun.com/signup
                              api_key: 'pubkey-83a6-sl6j2m3daneyobi87b3-ksx3q29'
                          },
                          dataType: 'jsonp',
                          validKey: 'is_valid',
                          message: "The email isn't valid"
                      }
                  }
              },
              'user[password]': {
                  row: '.group',
                  validators: {
                      stringLength: {
                          min: 8,
                          message: 'Your password should be at least 8 characters'
                      }
                  }
              },
              'user[password_confirmation]': {
                  row: '.group',
                  validators: {
                      identical: {
                          field: 'newPassword',
                          message: "The passwords don't match"
                      }
                  }
              },
              'user[phone]': {
                  row: '.group',
                  validators: {
                      callback: {
                          callback: function (value, validator, $field) {
                              if (PhoneNumberFormatter.isValid()) {
                                  return {
                                      valid: true,    // or false
                                      message: 'Valid number'
                                  }
                              } else {
                                  return {
                                      valid: false,    // or false
                                      message: 'Enter a valid number'
                                  }
                              }
                          }
                      }
                  }
              },
              'user[full_name]': {
                  row: '.group',
                  validators: {
                      notEmpty: {
                          message: 'Your full name is required'
                      }
                  }
              },
              /// why did i put this here?????
              /*
              'user[current_password]': {
                  row: '.group',
                  validators: {
                      notEmpty: {
                          message: 'The password is required'
                      },
                      stringLength: {
                          min: 8,
                          message: 'Your password should be at least 8 characters'
                      }
                  }
              },*/
          }
      })
      .on('success.validator.fv', function(e, data) {
          if (data.field === 'email' && data.validator === 'remote') {
              var response = data.result;  // response is the result returned by MailGun API
              if (response.did_you_mean) {
                  // Update the message
                  data.element                    // The field element
                      .data('fv.messages')        // The message container
                      .find('[data-fv-validator="remote"][data-fv-for="email"]')
                      .html('Did you mean ' + response.did_you_mean + '?')
                      .show();
              }
          }
      })
      .on('err.validator.fv', function(e, data) {
        if (data.field === 'email' && data.validator === 'remote') {
          // We need to reset the error message
          data.element                // The field element
              .data('fv.messages')    // The message container
              .find('[data-fv-validator="remote"][data-fv-for="email"]')
              .html("The email isn't valid")
              .show();
        }
      })
      .on('success.form.fv', function(e, data) {
        PhoneNumberFormatter.set_phone_number();
      });
  ///


  // validate sign up form
  $('#signupForm')
      .formValidation({
          // I am validating Bootstrap form
          framework: 'bootstrap',
          live: 'disabled',
          // List of fields and their validation rules!
          fields: {
              'user[email]': {
                  verbose: false,
                  validators: {
                      notEmpty: {
                          message: 'Your email is required'
                      },
                      emailAddress: {
                          message: "The email isn't valid"
                      },
                      remote: {
                          type: 'GET',
                          url: 'https://api.mailgun.net/v2/address/validate?callback=?',
                          crossDomain: true,
                          name: 'address',
                          data: {
                              // Registry a Mailgun account and get a free API key
                              // at https://mailgun.com/signup
                              api_key: 'pubkey-83a6-sl6j2m3daneyobi87b3-ksx3q29'
                          },
                          dataType: 'jsonp',
                          validKey: 'is_valid',
                          message: "The email isn't valid"
                      }
                  }
              },
              'user[password]': {
                  validators: {
                      notEmpty: {
                          message: 'The password is required'
                      },
                      stringLength: {
                          min: 8,
                          message: 'Your password should be at least 8 characters'
                      }
                  }
              },
              "user[password_confirmation]": {
                  validators: {
                      verbose: false,
                      notEmpty: {
                          message: 'The password confirmation is required'
                      },
                      identical: {
                          field: 'password',
                          message: "The passwords don't match"
                      }
                  }
              },
              'user[phone]': {
                  validators: {
                      callback: {
                          callback: function (value, validator, $field) {
                              if (PhoneNumberFormatter.isValid()) {
                                  return {
                                      valid: true,    // or false
                                      message: 'Valid number'
                                  }
                              } else {
                                  return {
                                      valid: false,    // or false
                                      message: 'Enter a valid number'
                                  }
                              }
                          }
                      }
                  }
              },
              'user[user_level]': {
                  validators: {
                      notEmpty: {
                          message: 'Please select an account'
                      }
                  }
              }
          }
      })
      .on('success.validator.fv', function(e, data) {
          if (data.field === 'user[email]' && data.validator === 'remote') {
              var response = data.result;  // response is the result returned by MailGun API
              if (response.did_you_mean) {
                  // Update the message
                  data.element                    // The field element
                      .data('fv.messages')        // The message container
                      .find('[data-fv-validator="remote"][data-fv-for="user[email]"]')
                      .html('Did you mean ' + response.did_you_mean + '?')
                      .show();
              }
          }
      })
      .on('err.validator.fv', function(e, data) {
          if (data.field === 'user[email]' && data.validator === 'remote') {
              // We need to reset the error message
              data.element                // The field element
                  .data('fv.messages')    // The message container
                  .find('[data-fv-validator="remote"][data-fv-for="user[email]"]')
                  .html("The email isn't valid")
                  .show();
          }
      })
      .on('success.form.fv', function(e, data) {
          PhoneNumberFormatter.set_phone_number();
          set_hidden_fields();
      });
    // validate sign up form

  function set_hidden_fields() {
    if (global_page_params['referrer_id']) document.getElementById('referrer_id').value = global_page_params['referrer_id'];
    if (global_page_params['referrer_uid']) document.getElementById('referrer_uid').value = global_page_params['referrer_uid'];
    if (global_page_params['msg_id']) document.getElementById('msg_id').value = global_page_params['msg_id'];
    if (global_page_params['tag_id']) document.getElementById('tag_id').value = global_page_params['tag_id'];
  }

  // validate password change form
  $('#changePasswordForm')
      .formValidation({
          // I am validating Bootstrap form
          framework: 'bootstrap',
          live: 'disabled',

          // List of fields and their validation rules!
          fields: {
              'user[password]': {
                  row: '.group',
                  validators: {
                      notEmpty: {
                          message: 'The password is required'
                      },
                      stringLength: {
                          min: 8,
                          message: 'Your password should be at least 8 characters'
                      }
                  }
              },
              'user[password_confirmation]': {
                  row: '.group',
                  validators: {
                      verbose: false,
                      notEmpty: {
                          message: 'The password confirmation is required'
                      },
                      identical: {
                          field: 'password',
                          message: "The passwords don't match"
                      }
                  }
              }
          }
      });


  // validate merchant profile
  $('#merchantProfile')
      .find('[name="user[org_category]"]')
          .selectpicker()
          .change(function(e) {
              $('#merchantProfile').formValidation('revalidateField', 'user[org_category]');
          })
          .end()
      .find('[name="user[country]"]')
          .selectpicker()
          .change(function(e) {
              $('#merchantProfile').formValidation('revalidateField', 'user[country]');
          })
          .end()
      .find('[name="user[currency]"]')
          .selectpicker()
          .change(function(e) {
              $('#merchantProfile').formValidation('revalidateField', 'user[currency]');
          })
          .end()
      .formValidation({
          // I am validating Bootstrap form
          framework: 'bootstrap',
          live: 'disabled',
          // List of fields and their validation rules!
          fields: {
              'user[email]': {
                  verbose: false,
                  row: '.form-group',
                  validators: {
                      notEmpty: {
                          message: 'Your email is required'
                      },
                      emailAddress: {
                          message: "The email isn't valid"
                      },
                      remote: {
                          type: 'GET',
                          url: 'https://api.mailgun.net/v2/address/validate?callback=?',
                          crossDomain: true,
                          name: 'address',
                          data: {
                              // Registry a Mailgun account and get a free API key
                              // at https://mailgun.com/signup
                              api_key: 'pubkey-83a6-sl6j2m3daneyobi87b3-ksx3q29'
                          },
                          dataType: 'jsonp',
                          validKey: 'is_valid',
                          message: "The email isn't valid"
                      }
                  }
              },
              'user[password]': {
                  row: '.form-group',
                  validators: {
                      stringLength: {
                          min: 8,
                          message: 'Your password should be at least 8 characters'
                      }
                  }
              },
              'user[password_confirmation]': {
                  row: '.form-group',
                  validators: {
                      identical: {
                          field: 'password',
                          message: "The passwords don't match"
                      }
                  }
              },
              'user[phone]': {
                  row: '.form-group',
                  validators: {
                      callback: {
                          callback: function (value, validator, $field) {
                              if (PhoneNumberFormatter.isValid()) {
                                  return {
                                      valid: true,    // or false
                                      message: 'Valid number'
                                  }
                              } else {
                                  return {
                                      valid: false,    // or false
                                      message: 'Enter a valid number'
                                  }
                              }
                          }
                      }
                  }
              },
              'user[first_name]': {
                  row: '.form-group',
                  validators: {
                      notEmpty: {
                          message: 'Your first name is required'
                      }
                  }
              },
              'user[tax_percent]': {
                  row: '.form-group',
                  validators: {
                      numeric: {
                          message: 'Tax rate should be number'
                      }
                  }
              },
              'user[last_name]': {
                  row: '.form-group',
                  validators: {
                      notEmpty: {
                          message: 'Your last name is required'
                      }
                  }
              },
              'user[org_name]': {
                  row: '.form-group',
                  validators: {
                      notEmpty: {
                          message: 'Your business name is required'
                      }
                  }
              },
              'user[url]': {
                  row: '.form-group',
                  validators: {
                      notEmpty: {
                          message: 'Your website or social profile url is required'
                      },
                      uri: {
                          message: 'The url is not valid (you might need to add http://)'
                      }
                  }
              },
              'user[org_category]': {
                  row: '.form-group',
                  validators: {
                      notEmpty: {
                          message: 'Please select a business type'
                      }
                  }
              },
              'user[street_address]': {
                  row: '.form-group',
                  validators: {
                      notEmpty: {
                          message: 'Your address is required'
                      }
                  }
              },
              'user[country]': {
                  row: '.form-group',
                  validators: {
                      notEmpty: {
                          message: 'Please select your country'
                      }
                  }
              },
              'user[currency]': {
                  row: '.form-group',
                  validators: {
                      notEmpty: {
                          message: 'Please select a currency'
                      }
                  }
              },
              'user[zip_code]': {
                  row: '.form-group',
                  validators: {
                      notEmpty: {
                          message: 'Please enter your zip code'
                      }
                  }
              },/* if you need merchants to confirm password
              'user[current_password]': {
                  row: '.form-group',
                  validators: {
                      notEmpty: {
                          message: 'Please re-enter your account password'
                      }
                  }
              },*/
              'user[city]': {
                  row: '.form-group',
                  validators: {
                      notEmpty: {
                          message: 'Please enter your city'
                      }
                  }
              },
              'user[state_province]': {
                  row: '.form-group',
                  validators: {
                      notEmpty: {
                          message: 'Please enter your state or province'
                      }
                  }
              },
          }
      })
      .on('success.validator.fv', function(e, data) {
          if (data.field === 'email' && data.validator === 'remote') {
              var response = data.result;  // response is the result returned by MailGun API
              if (response.did_you_mean) {
                  // Update the message
                  data.element                    // The field element
                      .data('fv.messages')        // The message container
                      .find('[data-fv-validator="remote"][data-fv-for="email"]')
                      .html('Did you mean ' + response.did_you_mean + '?')
                      .show();
              }
          }
      })
      .on('err.validator.fv', function(e, data) {
          if (data.field === 'email' && data.validator === 'remote') {
              // We need to reset the error message
              data.element                // The field element
                  .data('fv.messages')    // The message container
                  .find('[data-fv-validator="remote"][data-fv-for="email"]')
                  .html("The email isn't valid")
                  .show();
          }
      })
      .on('success.form.fv', function(e, data) {
          PhoneNumberFormatter.set_phone_number();
      });
  // validate merchant profile form

  /*var zip = $("#zip");
  var c = $('#country');
  var a = $('#address');
  zip.blur(function() {
      $('#city, #state').val('');
      var x = (a.val()) ? a.val() : '';
      var y = (c.val()) ? c.val() : '';
      var z = (zip.val()) ? zip.val() : '';
      var param = x.trim() + ", " + z.trim() + ", " + y.trim();
      if (param) {
          var jqxhr = $.getJSON('https://maps.googleapis.com/maps/api/geocode/json?address=' + param, function() {
          })
            .done(function(res) {
              $('#city').val('');
              $('#state').val('');

              console.log(res.results[0]['address_components'][1]["long_name"]);
              console.log(res.results[0]['address_components'][2]["short_name"]);
              $('.city-state').val(res.results[0]['formatted_address']);
            })
            .fail(function() {
              $('#city, #state').val('');
            })
      }
  });*/

  // character counter
  $("#count_me").counter();


  //// for number search - move to separate file
  searchNumBtn.click(function() {
      this.disabled = true;
      this.innerHTML = "Searching...";
      get_number();
  });

  var searchNumberCountry = $('#searchNumberCountry'),
      searchNumberType = $('#searchNumberType'),
      searchNumberField = $('#searchNumberField');
  var get_number = function(str) {
    $.ajax({
      url: "/v1/numbers/search.json",
      type: "GET",
      data: { query: searchNumberField.val(), country: searchNumberCountry.val(), type: searchNumberType.val() },
      dataType: "json"
    })
      .done(function(data, textStatus, jqXHR) {
          var str = '';
          if(data.error) {
              alert('something went wrong');
          } else if (data.number == '') {
              alert(':( we dont have any number');
          } else {
              alert(data.number);
          }
      })
      .fail(function(data, textStatus, errorThrown) {
          alert('something went wrong');
           console.log(data);
      })
      .always(function(data, textStatus, response) {
          searchNumBtn.html('Search').prop("disabled", false);
      });
  }

  var country_num_types = {
        US: { types: ["Local","Toll Free"], show: true },
        CA: { types: ["Local","Toll Free"], show: true },
        PR: { types: ["Local"] },
        GB: { types: ["Local"] },
        // else mobile and don't show
  };

  searchNumberCountry.change(function() {
      var x = country_num_types[this.options[this.selectedIndex].value.toString()], html = '';
      x = (x) ? x : { types: ["mobile"] };
      for (i = 0, len = x.types.length; i < len; i++) {
          html += '<option value="' + x.types[i].toLowerCase().replace(/ /g, '_') + '">' + x.types[i] + '</option>'
      }
      var display = (x.show) ? 'inline' : 'none';
      searchNumberType.html(html).css('display', display);
      searchNumberField.val('').css('display', display)
  });
  //// for number search



  // http://blog.teamtreehouse.com/uploading-files-ajax
  // but modified to send just one file.
  $('#csv-upload-form').submit(function(e) {
    e.preventDefault();
    var button = $('#csv-upload-button').text("Uploading...").prop('disabled', true);

    function send_payload(payload) {
      var xhr = new XMLHttpRequest();             // Set up the request.
      xhr.open('POST', '/v1/users/add_customers.csv', true);    // Open the connection.
      xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'));
      xhr.onload = function () {
        if (xhr.readyState === 4) {
          if (xhr.status === 200) {
          } else {
            console.log('Something went wrong on our end.')
          }
          console.log(JSON.parse(xhr.responseText));
          button.text("Upload").prop('disabled', false);
        }
      };

      xhr.onerror = function (e) {
        console.log(xhr.statusText);
        button.text("Upload").prop('disabled', false);
      };
      xhr.send(payload);        // Send the Data.
    }

    var file = document.getElementById('csv-file-select').files;            // Get the selected files from the input.
    if (file && file.length == 1) {
      file = file[0];
      if (!file.type.match('csv')) {             // Check the file type.
        alert("Can't upload file type");
        button.text("Upload").prop('disabled', false);
        return;
      }

      var formData = new FormData();               // Create a new FormData object.
      formData.append('csv', file, file.name);    // Add the file to the request.
      send_payload(formData);
    } else {
      button.text("Upload").prop('disabled', false);
    }
  });
  // end csv file upload


  // submit referrer
  $("#new_referrer").on("ajax:success", function(e, data, status, xhr) {
    alert('received referral info. pls share the link and refer more');
    console.log(data.referrer.link)
  }).on("ajax:error", function(e, xhr, status, error){
    alert('unable to save referral info');
  });
  // submit referrer

});


function get_unread_messages() {
    // getting unread messages and subcribing to messaging channel
    var global_unread_count = 0;
    var url = window.location;
    $.ajax({
        url: url.origin + '/get_current_user',
        type: "GET",
        dataType: "json"
    })
        .done(function(data, textStatus, response) {
            var merchant_id = data.id;
            // Initialize PubNub with SSL
            var pubnub = PUBNUB({
                publish_key: data.pubnub_publish_key,
                subscribe_key: data.pubnub_subscribe_key,
                ssl: true
            });

            // Subscribe to merchant channel
            pubnub.subscribe({
                channel: 'messaging_development_' + merchant_id,
                message: function(m){
                    var json_response = JSON.parse(m[0]);
                    if (json_response.user_level == 0) {
                        global_unread_count += 1;
                        document.getElementById('unreadCount').textContent = (global_unread_count > 0) ? global_unread_count : '';
                    }
                }
            });

            // Get latest messages for this merchant
            $.ajax({
                url: url.origin + '/users/' + merchant_id + '/json_get_latest_active_messaging',
                type: "GET",
                dataType: "json"
            })
                .done(function(data, textStatus, response) {
                    $.each(data.users, function( index, value ){
                        global_unread_count += value.unread_count;
                    });
                    document.getElementById('unreadCount').textContent = (global_unread_count > 0) ? global_unread_count : '';
                })
                .fail(function(data, textStatus, response) {
                    console.log('Error while trying to connect to the messaging system.');
                    document.getElementById('unreadCount').textContent = '';
                })
        })
        .fail(function(data, textStatus, response) {
            console.log('Error while trying to connect to the messaging system.');
            document.getElementById('unreadCount').textContent = '';
        })
}


;
