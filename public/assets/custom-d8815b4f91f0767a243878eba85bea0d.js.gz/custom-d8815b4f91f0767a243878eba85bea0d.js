$(document).ready(function () {  

    var url = window.location;
    Stripe.setPublishableKey('pk_test_hQV92i1Ip5Blrrvh7ivixlRY');
    var page_params = url.search.substring(1);
    var cc_year, cc_month, txn_details;
    var chart_labels = [], chart_totals = [], chart_txns = [];
    $.ajaxSetup({ cache:false });
    var contact_url = '/contact_forms.json';
   
    // to prefill signup form
    if (url.pathname == "/signup") {
        if (page_params != "") {
            document.getElementById('phone').value = GetURLParameter(page_params, 'num');
            var referrer = GetURLParameter(page_params, 'referrer');
            if (referrer) {
                var x = $("#signup_logo");
                $("<h2 class='referrer'>" + referrer + "</h2>").insertAfter(x);
                x.remove();
                $("#rhombusPower").removeClass('hide');
            } else {
                $("#rhombusPower").addClass('hide');
            }
        }
    }


    ///// toggle card/login info for user's profile
    $('#next').click(function() {
        $('#user-form').toggleClass('show');
        $('#user-profile-form').toggleClass('show');
    });

    $('#Prev').click(function() {
        $('#user-profile-form').toggleClass('show');
        $('#user-form').toggleClass('show');
    });
    /////


    function GetURLParameter(page_params, sParam) {
        if (page_params) {
            var sPageURL = page_params;
            var sURLVariables = sPageURL.split('&');
            for (var i = 0; i < sURLVariables.length; i++) {
                var sParameterName = sURLVariables[i].split('=');
                if (sParameterName[0] == sParam) return decodeURIComponent(sParameterName[1]);
            }
        }
    }

    // /* Sidebar Menu*/
    $('.nav > li > a').click(function(){
        if ($(this).attr('class') != 'active') {
            $('.nav li ul').slideUp();
            $(this).next().slideToggle();
            $('.nav li a').removeClass('active');
            $(this).addClass('active');
        }
    });

    /* Top Stats Show Hide */
    /*$("#topstats").click(function(){
        $(".topstats").slideToggle(100);
    });*/


    /* Sidebar Show-Hide On Mobile */
    $(".sidebar-open-button-mobile").click(function(){
        $(".sidebar").toggle(150);
    });


    /* Sidebar Show-Hide */
    $('.sidebar-open-button').on('click', function(){
        if($('.sidebar').hasClass('hidden')){
            $('.sidebar').removeClass('hidden');
            $('.content').css({
                'marginLeft' : 250
            });  
        }else{
            $('.sidebar').addClass('hidden');
            $('.content').css({
                'marginLeft' : 0
            });    
        }
    });
    //

    /* ===========================================================
    PANEL TOOLS
    ===========================================================*/
    /* Minimize */
    $(".panel-tools .minimise-tool").click(function(event){
        $(this).parents(".panel").find(".panel-body").slideToggle(100);
        return false;
    });  

    /* Close */
    /* $(".panel-tools .closed-tool").click(function(event){
        $(this).parents(".panel").fadeToggle(400);
        return false;
    }); */
    /* Search */
    /*$(".panel-tools .search-tool").click(function(event){
        $(this).parents(".panel").find(".panel-search").toggle(100);
    }); */

    /* expand */
    $('.panel-tools .expand-tool').on('click', function(){
        if($(this).parents(".panel").hasClass('panel-fullsize'))
        {
            $(this).parents(".panel").removeClass('panel-fullsize');
        }
        else
        {
            $(this).parents(".panel").addClass('panel-fullsize');
 
        }
    });

    var get_graph = function(type) {
        // run only on dashboard
        if ($("#isDashboard").attr('data-dashboard') === "true") {
            $.ajax({
                url: url.href,
                type: "GET",
                data: 'graph=' + type, 
                dataType: "json"     
            })
              .done(function(data, textStatus, response) {
                   process_chart_data(data, type);
              })
              .fail(function(data, textStatus, response) {
                   process_chart_data([], type);
              })        
        }
    };


    var process_chart_data = function(data, type) {
        chart_labels = [], chart_totals = [], chart_txns = [];
        if (type === "line") {
            for (var i = 0, array_length = data.length; i < array_length; i++) {
                chart_labels.push(data[i].day);
                chart_totals.push(data[i].day_total);
                chart_txns.push(data[i].num_of_txns);
            }
        } else {
            for (var i = 0, array_length = data.length; i < array_length; i++) {
                chart_labels.push(data[i].week_day);
                chart_totals.push(data[i].week_total);
            }
        }
        if (chart_labels.length == 0) chart_labels = ['Mon', 'Tue', 'Wed', 'Thur', 'Fri'];
        (type === "line") ? graph_line_chart() : graph_area_chart();
    }

    
    var graph_line_chart = function() {
        new Chartist.Line('#chartist-line', {
          labels: chart_labels,
          series: [
            chart_txns,
            chart_totals
          ]
        }, {
          fullWidth: true,
          chartPadding: {
            right: 40
          }
        }); 
    }


    var graph_area_chart = function() {
        new Chartist.Line('#chartist-line-area', {
          labels: chart_labels,
          series: [
            chart_totals
          ]
        }, {
          low: 0,
          showArea: true
        });
    }

    // graphs by chartist.js
    get_graph('line');
    get_graph('area');

    
    // for table slide dowm
    function format ( d, element ) {
        // `d` is the original data object for the row
        var x = '<div class="slider">'+
            '<table cellpadding="5" cellspacing="0" border="0" style="padding-left:50px;">'+
                '<tr>'+
                    '<td>Email:</td>'+
                    '<td>'+ element.attr('data-email') +'</td>'+
                '</tr>';
        var x, y;
        if (element.attr('data-page') === 'transactions') {
            y = '<tr>' +
                        '<td>Rhombus Txn #:</td>'+
                        '<td>'+ element.attr('data-txn-num') +'</td>'+
                    '</tr>'+
                    '<tr>'+
                        '<td>Time (ET):</td>'+
                        '<td>'+ element.attr('data-time') +'</td>'+
                    '</tr>'+
                    '<tr>'+
                        '<td>Stripe Txn #:</td>'+
                        '<td>' + element.attr('data-stripe-txn-num') + '</td>'+
                    '</tr>'+
                    '<tr>'+
                        '<td>Taxes and Fees:</td>'+
                        '<td>' + element.attr('data-tax') + '</td>'+
                    '</tr>'+
                '</table>'+
            '</div>';
        } else {
            z = '<tr>'+
                        '<td>Phone #:</td>'+
                        '<td>' + element.attr('data-phone') + '</td>'+
                    '</tr>'+
                   '</table>'+
                '</div>';
        }

        return (element.attr('data-page') === "transactions") ? x + y : x + z;
    }

    // for table slide dowm
    var table = $('#transactions-table').DataTable({ 
        'dom' : 't'
    });


    // Add event listener for opening and closing details
    $('#transactions-table tbody').on('click', 'td.details-control', function () {
        //$(this).addClass('');
        var tr = $(this).closest('tr');
        var row = table.row( tr );
        if ( row.child.isShown() ) {
            // This row is already open - close it
            $('div.slider', row.child()).slideUp( function () {
                row.child.hide();
                tr.removeClass('shown');
            } );
        }
        else {
            // Open this row
            row.child(format(row.data(), $(this)), 'no-padding').show();
            tr.addClass('shown');
 
            $('div.slider', row.child()).slideDown();
        }
    });
    //// end table slide down


    // refresh page
    $('#refresh').click( function() {
        url.reload(true);
    });


    // bootstrap -select plugin
    $('#signupForm .selectpicker').selectpicker({
        mobile: true,
        width: "inherit"
    });
    $('#merchantProfile .selectpicker').selectpicker({
        mobile: true
    });
    // bootstrap -select plugin


    // for 404 page...go back
    $('#go-back').click(function(event) {
        event.preventDefault();
        window.history.back();
    });
    /////


    // For phone number input field
    var telInput = $("#phone");
    telInput.intlTelInput({
        nationalMode: true,
        defaultCountry: "auto",
        utilsScript: "/assets/utils-31556d6e5004c57abe8f1213b07fa392.js" // just for formatting/placeholders etc
    });

   
    // validate signin form
    $('#signinForm')
        .formValidation({
            // I am validating Bootstrap form
            framework: 'bootstrap',
            live: 'disabled',

            // Feedback icons
            /*icon: {
                valid: 'fa fa-check',
                invalid: 'fa fa-times',
                validating: 'fa fa-refresh'
            },*/

            // List of fields and their validation rules
            fields: {
                'user[email]': {
                    verbose: false,
                    row: '.group',
                    validators: {
                        notEmpty: {
                            message: 'Your email is required'
                        },
                        emailAddress: {
                            message: "The email isn't valid"
                        },
                        remote: {
                            type: 'GET',
                            url: 'https://api.mailgun.net/v2/address/validate?callback=?',
                            crossDomain: true,
                            name: 'address',
                            data: {
                                // Registry a Mailgun account and get a free API key
                                // at https://mailgun.com/signup
                                api_key: 'pubkey-83a6-sl6j2m3daneyobi87b3-ksx3q29'
                            },
                            dataType: 'jsonp',
                            validKey: 'is_valid',
                            message: "The email isn't valid"
                        }
                    }
                },
                'user[password]': {
                    row: '.group',
                    validators: {
                        notEmpty: {
                            message: 'Your password is required'
                        }
                    }
                }
            }
        })
        .on('success.validator.fv', function(e, data) {
            if (data.field === 'email' && data.validator === 'remote') {
                var response = data.result;  // response is the result returned by MailGun API
                if (response.did_you_mean) {
                    // Update the message
                    data.element                    // The field element
                        .data('fv.messages')        // The message container
                        .find('[data-fv-validator="remote"][data-fv-for="email"]')
                        .html('Did you mean ' + response.did_you_mean + '?')
                        .show();
                }
            }
        })
        .on('err.validator.fv', function(e, data) {
            if (data.field === 'email' && data.validator === 'remote') {
                // We need to reset the error message
                data.element                // The field element
                    .data('fv.messages')    // The message container
                    .find('[data-fv-validator="remote"][data-fv-for="email"]')
                    .html("The email isn't valid")
                    .show();
            }
        });
    ////


    // validate forgot password form
    $('#ForgotPassword')
        .formValidation({
            // I am validating Bootstrap form
            framework: 'bootstrap',
            live: 'disabled',
            // List of fields and their validation rules
            fields: {
                'user[email]': {
                    verbose: false,
                    row: '.group',
                    validators: {
                        notEmpty: {
                            message: 'Your email is required'
                        },
                        emailAddress: {
                            message: "The email isn't valid"
                        },
                        remote: {
                            type: 'GET',
                            url: 'https://api.mailgun.net/v2/address/validate?callback=?',
                            crossDomain: true,
                            name: 'address',
                            data: {
                                // Registry a Mailgun account and get a free API key
                                // at https://mailgun.com/signup
                                api_key: 'pubkey-83a6-sl6j2m3daneyobi87b3-ksx3q29'
                            },
                            dataType: 'jsonp',
                            validKey: 'is_valid',
                            message: "The email isn't valid"
                        }
                    }
                }
            }
        })
        .on('success.validator.fv', function(e, data) {
            if (data.field === 'email' && data.validator === 'remote') {
                var response = data.result;  // response is the result returned by MailGun API
                if (response.did_you_mean) {
                    // Update the message
                    data.element                    // The field element
                        .data('fv.messages')        // The message container
                        .find('[data-fv-validator="remote"][data-fv-for="email"]')
                        .html('Did you mean ' + response.did_you_mean + '?')
                        .show();
                }
            }
        })
        .on('err.validator.fv', function(e, data) {
            if (data.field === 'email' && data.validator === 'remote') {
                // We need to reset the error message
                data.element                // The field element
                    .data('fv.messages')    // The message container
                    .find('[data-fv-validator="remote"][data-fv-for="email"]')
                    .html("The email isn't valid")
                    .show();
            }
        });
    // validate forgot password form


    // user profile forms
    $('#user-profile-form')
        .formValidation({
            // I am validating Bootstrap form
            framework: 'bootstrap',
            live: 'disabled',

            // List of fields and their validation rules!
            fields: {
                'user[email]': {
                    verbose: false,
                    row: '.group',
                    validators: {
                        notEmpty: {
                            message: 'Your email is required'
                        },
                        emailAddress: {
                            message: "The email isn't valid"
                        },
                        remote: {
                            type: 'GET',
                            url: 'https://api.mailgun.net/v2/address/validate?callback=?',
                            crossDomain: true,
                            name: 'address',
                            data: {
                                // Registry a Mailgun account and get a free API key
                                // at https://mailgun.com/signup
                                api_key: 'pubkey-83a6-sl6j2m3daneyobi87b3-ksx3q29'
                            },
                            dataType: 'jsonp',
                            validKey: 'is_valid',
                            message: "The email isn't valid"
                        }
                    }
                },
                'user[password]': {
                    row: '.group',
                    validators: {
                        stringLength: {
                            min: 8,
                            message: 'Your password should be at least 8 characters'
                        }
                    }
                },
                'user[password_confirmation]': {
                    row: '.group',
                    validators: {
                        identical: {
                            field: 'newPassword',
                            message: "The passwords don't match"
                        }
                    }
                },
                'user[phone]': {
                    row: '.group',
                    validators: {
                        callback: {
                            callback: function (value, validator, $field) {
                                if (telInput.intlTelInput("isValidNumber")) {
                                    return {
                                        valid: true,    // or false
                                        message: 'Valid number'
                                    }
                                } else {
                                    return {
                                        valid: false,    // or false
                                        message: 'Enter a valid number'
                                    }
                                }
                            }
                        }
                    }
                },
                'user[full_name]': { 
                    row: '.group',
                    validators: {
                        notEmpty: {
                            message: 'Your full name is required'
                        }
                    }
                },
                'user[current_password]': {
                    row: '.group',
                    validators: {
                        notEmpty: {
                            message: 'The password is required'
                        },
                        stringLength: {
                            min: 8,
                            message: 'Your password should be at least 8 characters'
                        }
                    }
                },
            }
        })
        .on('success.validator.fv', function(e, data) {
            if (data.field === 'email' && data.validator === 'remote') {
                var response = data.result;  // response is the result returned by MailGun API
                if (response.did_you_mean) {
                    // Update the message
                    data.element                    // The field element
                        .data('fv.messages')        // The message container
                        .find('[data-fv-validator="remote"][data-fv-for="email"]')
                        .html('Did you mean ' + response.did_you_mean + '?')
                        .show();
                }
            }
        })
        .on('err.validator.fv', function(e, data) {
            if (data.field === 'email' && data.validator === 'remote') {
                // We need to reset the error message
                data.element                // The field element
                    .data('fv.messages')    // The message container
                    .find('[data-fv-validator="remote"][data-fv-for="email"]')
                    .html("The email isn't valid")
                    .show();
            }
        })
        .on('success.form.fv', function(e, data) {
            set_number();
            set_names();
        });
    ///


    // validate sign up form
    $('#signupForm')
        .find('[name="user[user_level]"]')
            .selectpicker()
            .change(function(e) {
                $('#signupForm').formValidation('revalidateField', 'user[user_level]');
            })
            .end()
        .formValidation({
            // I am validating Bootstrap form
            framework: 'bootstrap',
            live: 'disabled',
            // List of fields and their validation rules!
            fields: {
                'user[email]': {
                    verbose: false,
                    row: '.group',
                    validators: {
                        notEmpty: {
                            message: 'Your email is required'
                        },
                        emailAddress: {
                            message: "The email isn't valid"
                        },
                        remote: {
                            type: 'GET',
                            url: 'https://api.mailgun.net/v2/address/validate?callback=?',
                            crossDomain: true,
                            name: 'address',
                            data: {
                                // Registry a Mailgun account and get a free API key
                                // at https://mailgun.com/signup
                                api_key: 'pubkey-83a6-sl6j2m3daneyobi87b3-ksx3q29'
                            },
                            dataType: 'jsonp',
                            validKey: 'is_valid',
                            message: "The email isn't valid"
                        }
                    }
                },
                'user[password]': {
                    row: '.group',
                    validators: {
                        notEmpty: {
                            message: 'The password is required'
                        },
                        stringLength: {
                            min: 8,
                            message: 'Your password should be at least 8 characters'
                        }
                    }
                },
                "user[password_confirmation]": {
                    row: '.group',
                    validators: {
                        verbose: false,
                        notEmpty: {
                            message: 'The password confirmation is required'
                        },
                        identical: {
                            field: 'password',
                            message: "The passwords don't match"
                        }
                    }
                },
                'user[phone]': {
                    row: '.group',
                    validators: {
                        callback: {
                            callback: function (value, validator, $field) {
                                if (telInput.intlTelInput("isValidNumber")) {
                                    return {
                                        valid: true,    // or false
                                        message: 'Valid number'
                                    }
                                } else {
                                    return {
                                        valid: false,    // or false
                                        message: 'Enter a valid number'
                                    }
                                }
                            }
                        }
                    }
                },
                'user[user_level]': {
                    row: '.form-group',
                    validators: {
                        notEmpty: {
                            message: 'Please select an account'
                        }
                    }
                }
            }
        })
        .on('success.validator.fv', function(e, data) {
            if (data.field === 'user[email]' && data.validator === 'remote') {
                var response = data.result;  // response is the result returned by MailGun API
                if (response.did_you_mean) {
                    // Update the message
                    data.element                    // The field element
                        .data('fv.messages')        // The message container
                        .find('[data-fv-validator="remote"][data-fv-for="user[email]"]')
                        .html('Did you mean ' + response.did_you_mean + '?')
                        .show();
                }
            }
        })
        .on('err.validator.fv', function(e, data) {
            if (data.field === 'user[email]' && data.validator === 'remote') {
                // We need to reset the error message
                data.element                // The field element
                    .data('fv.messages')    // The message container
                    .find('[data-fv-validator="remote"][data-fv-for="user[email]"]')
                    .html("The email isn't valid")
                    .show();
            }            
        })
        .on('success.form.fv', function(e, data) {
            set_number();
            // set referrer number, set subscription
            var referrer_num = GetURLParameter(page_params, 'referrer_num');
            var subscription_type = GetURLParameter(page_params, 'subscription_type');
            document.getElementById('referrer_num').value = (referrer_num) ? referrer_num : '';
            document.getElementById('subscription_type').value = (subscription_type) ? subscription_type : 0; 
        });
    // validate sign up form


    // validate password change form    
    $('#changePasswordForm')
        .formValidation({
            // I am validating Bootstrap form
            framework: 'bootstrap',
            live: 'disabled',

            // List of fields and their validation rules!
            fields: {
                'user[password]': {
                    row: '.group',
                    validators: {
                        notEmpty: {
                            message: 'The password is required'
                        },
                        stringLength: {
                            min: 8,
                            message: 'Your password should be at least 8 characters'
                        }
                    }
                },
                'user[password_confirmation]': {
                    row: '.group',
                    validators: {
                        verbose: false,
                        notEmpty: {
                            message: 'The password confirmation is required'
                        },
                        identical: {
                            field: 'password',
                            message: "The passwords don't match"
                        }
                    }
                }
            }
        });


    // validate merchant profile
    $('#merchantProfile')
        .find('[name="user[business_type]"]')
            .selectpicker()
            .change(function(e) {
                $('#merchantProfile').formValidation('revalidateField', 'user[business_type]');
            })
            .end()
        .find('[name="user[country]"]')
            .selectpicker()
            .change(function(e) {
                $('#merchantProfile').formValidation('revalidateField', 'user[country]');
            })
            .end()
        .formValidation({
            // I am validating Bootstrap form
            framework: 'bootstrap',
            live: 'disabled',
            // List of fields and their validation rules!
            fields: {
                'user[email]': {
                    verbose: false,
                    row: '.form-group',
                    validators: {
                        notEmpty: {
                            message: 'Your email is required'
                        },
                        emailAddress: {
                            message: "The email isn't valid"
                        },
                        remote: {
                            type: 'GET',
                            url: 'https://api.mailgun.net/v2/address/validate?callback=?',
                            crossDomain: true,
                            name: 'address',
                            data: {
                                // Registry a Mailgun account and get a free API key
                                // at https://mailgun.com/signup
                                api_key: 'pubkey-83a6-sl6j2m3daneyobi87b3-ksx3q29'
                            },
                            dataType: 'jsonp',
                            validKey: 'is_valid',
                            message: "The email isn't valid"
                        }
                    }
                },
                'user[password]': {
                    row: '.form-group',
                    validators: {
                        stringLength: {
                            min: 8,
                            message: 'Your password should be at least 8 characters'
                        }
                    }
                },
                'user[password_confirmation]': {
                    row: '.form-group',
                    validators: {
                        identical: {
                            field: 'password',
                            message: "The passwords don't match"
                        }
                    }
                },
                'user[phone]': {
                    row: '.form-group',
                    validators: {
                        callback: {
                            callback: function (value, validator, $field) {
                                if (telInput.intlTelInput("isValidNumber")) {
                                    return {
                                        valid: true,    // or false
                                        message: 'Valid number'
                                    }
                                } else {
                                    return {
                                        valid: false,    // or false
                                        message: 'Enter a valid number'
                                    }
                                }
                            }
                        }
                    }
                },
                'user[first_name]': {
                    row: '.form-group',
                    validators: {
                        notEmpty: {
                            message: 'Your first name is required'
                        }
                    }
                },
                'user[tax_rate]': {
                    row: '.form-group',
                    validators: {
                        numeric: {
                            message: 'Tax rate should be number'
                        }
                    }
                },
                'user[last_name]': {
                    row: '.form-group',
                    validators: {
                        notEmpty: {
                            message: 'Your last name is required'
                        }
                    }
                },
                'user[business_name]': {
                    row: '.form-group',
                    validators: {
                        notEmpty: {
                            message: 'Your business name is required'
                        }
                    }
                },
                'user[url]': {
                    row: '.form-group',
                    validators: {
                        notEmpty: {
                            message: 'Your website or social profile url is required'
                        },
                        uri: {
                            message: 'The url is not valid (you might need to add http://)'
                        }
                    }
                },
                'user[business_type]': {
                    row: '.form-group',
                    validators: {
                        notEmpty: {
                            message: 'Please select a business type'
                        }
                    }
                },
                'user[street_address]': {
                    row: '.form-group',
                    validators: {
                        notEmpty: {
                            message: 'Your address is required'
                        }
                    }
                },
                'user[country]': {
                    row: '.form-group',
                    validators: {
                        notEmpty: {
                            message: 'Please select your country'
                        }
                    }
                },
                'user[business_zip_code]': {
                    row: '.form-group',
                    validators: {
                        notEmpty: {
                            message: 'Please enter your zip code'
                        }
                    }
                },
                'user[current_password]': {
                    row: '.form-group',
                    validators: {
                        notEmpty: {
                            message: 'Please re-enter your account password'
                        }
                    }
                },
                'user[city]': {
                    row: '.form-group',
                    validators: {
                        notEmpty: {
                            message: 'Please enter your city'
                        }
                    }
                },
                'user[state_province]': {
                    row: '.form-group',
                    validators: {
                        notEmpty: {
                            message: 'Please enter your state or province'
                        }
                    }
                },
            }
        })
        .on('success.validator.fv', function(e, data) {
            if (data.field === 'email' && data.validator === 'remote') {
                var response = data.result;  // response is the result returned by MailGun API
                if (response.did_you_mean) {
                    // Update the message
                    data.element                    // The field element
                        .data('fv.messages')        // The message container
                        .find('[data-fv-validator="remote"][data-fv-for="email"]')
                        .html('Did you mean ' + response.did_you_mean + '?')
                        .show();
                }
            }
        })
        .on('err.validator.fv', function(e, data) {
            if (data.field === 'email' && data.validator === 'remote') {
                // We need to reset the error message
                data.element                // The field element
                    .data('fv.messages')    // The message container
                    .find('[data-fv-validator="remote"][data-fv-for="email"]')
                    .html("The email isn't valid")
                    .show();
            }
        })
        .on('success.form.fv', function(e, data) {
            set_number(); 
        });
    // validate merchant profile form

   
    // Stripe form validator for CC form
    $('input#cc-number').payment('formatCardNumber');
    $('input#cc-exp').payment('formatCardExpiry');
    $('input#cc-csc').payment('formatCardCVC');

    // tokenize card details
    function submitToStripe() {        
        //console.log($('#cc-number').val())
        $("#cc-submit").attr("disabled", true);     
        $('#response').hide();
        $(".panel-body").html('');
        Stripe.card.createToken({
            name: $('#cc-name').val(),
            number: $('#cc-number').val(),
            exp_month: cc_month,
            exp_year: cc_year,
            cvc: $('#cc-csc').val()
        }, stripeResponseHandler);
    }  

    function stripeResponseHandler(status, response) {
        if (response.error) {
            // show the errors on the form
            $("#cc-submit").removeAttr("disabled");
            $('.panel-body').append(response.error.message);
            $('#response').slideDown(300);
        } else {
            $("#cc-submit").removeAttr("disabled");
            $("#cc-submit").text("Submitting...");            
            $('#cc-number').val(response['card']['last4']);
            $('#cc-ex-month').val(response['card']['exp_month']);
            $('#cc-ex-year').val(response['card']['exp_year']);
            document.getElementById('cc-uri').value = response.id;            
            $('#cc-type').val(response['card']['type']);
            $("#user-form").unbind("submit", preventDefault)
                    .submit();
            //$("#user-form").submit();
        }
    }
    ///// ///

    function preventDefault(e) {
        e.preventDefault();
    }

    // validate credit card form
    $('#user-form')
        .formValidation({
            // I am validating Bootstrap form
            framework: 'bootstrap',
            live: 'disabled',

            // List of fields and their validation rules
            fields: {
                'user[full_name]': { 
                    row: '.group',
                    validators: {
                        notEmpty: {
                            message: 'Your full name is required'
                        }
                    }
                },
                'cc-name': { 
                    selector: '#cc-name',
                    row: '.group',
                    validators: {
                        notEmpty: {
                            message: 'Your card name is required'
                        }
                    }
                },
                'user[current_password]': {
                    row: '.group',
                    validators: {
                        notEmpty: {
                            message: 'Your password is required'
                        }
                    }
                },
                'cc-number': {
                    selector: '#cc-number',
                    row: '.group',
                    validators: {
                        callback: {
                            callback: function (value, validator, $field) {
                                if ($.payment.validateCardNumber(value)) {
                                    return {
                                        valid: true,    // or false
                                        message: 'Valid number'
                                    }
                                } else {
                                    return {
                                        valid: false,    // or false
                                        message: 'Enter a valid number'
                                    }
                                }
                            }
                        }
                    }
                },
                'cc-exp': {
                    selector: '#cc-exp',
                    row: '#exp-div',
                    validators: {
                        callback: {
                            callback: function (value, validator, $field) {
                                var y = $('input#cc-exp').payment('cardExpiryVal');
                                cc_month = y.month; cc_year = y.year;
                                if ($.payment.validateCardExpiry(cc_month, cc_year)) {
                                    return {
                                        valid: true,    // or false
                                        message: 'Valid date'
                                    }
                                } else {
                                    return {
                                        valid: false,    // or false
                                        message: 'Enter a valid date'
                                    }
                                }
                            }
                        }
                    }
                },
                'cc-csc': {
                    selector: '#cc-csc',
                    row: '#csc-div',
                    validators: {
                        callback: {
                            callback: function (value, validator, $field) {
                                if ($.payment.validateCardCVC(value)) {
                                    return {
                                        valid: true,    // or false
                                        message: 'Valid csc'
                                    }
                                } else {
                                    return {
                                        valid: false,    // or false
                                        message: 'Enter a valid csc'
                                    }
                                }
                            }
                        }
                    }
                }
            }
        })
        .on('err.field.fv', function(e, data) {
            // $(e.target)  --> The field element
            // data.fv      --> The FormValidation instance
            // data.field   --> The field name
            // data.element --> The field element

            // Hide the messages
            data.element
                .data('fv.messages')
                .find('.help-block[data-fv-for="' + data.field + '"]').hide();
        })
        .on('success.form.fv', function(e, data) {            
            $("#user-form").bind("submit", preventDefault);
            set_names();            
            submitToStripe();
        });
    ///


    function set_names() {
        var fullname = (document.getElementById('user_full_name').value).trim();
        var firstName = fullname.substr(0, fullname.indexOf(' '));
        var lastName = fullname.substr(fullname.indexOf(' ')+1);
        if (!firstName && lastName) {
            firstName = lastName;
            lastName = "";
        }            
        document.getElementById('firstName').value = firstName;
        document.getElementById('lastName').value = lastName;         
    }

    function set_number() {
        var number = telInput.intlTelInput("getNumber");
        document.getElementById('phoneNumber').value = (number.charAt(0) === "+") ? number.substring(1) : number;
    }
    
    // Simply populates credit card and bank account fields with test data
    /*$('#populate').click(function () {
        $(this).attr("disabled", true);

        $('#cc-name').val('John Doe');
        $('#cc-number').val('4242424242424242');
        $('#cc-ex-month').val('12');
        $('#cc-ex-year').val('2020');
        $('#ex-csc').val('123');
    });*/

    /*var zip = $("#zip");
    var c = $('#country');
    var a = $('#address');
    zip.blur(function() {
        $('#city, #state').val('');
        var x = (a.val()) ? a.val() : ''; 
        var y = (c.val()) ? c.val() : ''; 
        var z = (zip.val()) ? zip.val() : ''; 
        var param = x.trim() + ", " + z.trim() + ", " + y.trim();
        if (param) {
            var jqxhr = $.getJSON('https://maps.googleapis.com/maps/api/geocode/json?address=' + param, function() {
            })
              .done(function(res) {
                $('#city').val('');
                $('#state').val('');
                
                console.log(res.results[0]['address_components'][1]["long_name"]);
                console.log(res.results[0]['address_components'][2]["short_name"]);
                $('.city-state').val(res.results[0]['formatted_address']);
              })
              .fail(function() {
                $('#city, #state').val('');
              })
        }
    });*/

    // character counter
    $("#count_me").counter({
        text: false,
        goal: 150
    });


    var submit_contact_form = function(json) {
        $.ajax({ url: contact_url,
            type: 'POST',
            beforeSend: function(xhr) {xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'))},
            data: json
        })  
            .done(function(data, response) {
                console.log(response);
                ohSnap('Yes! Your message has been sent!', 'green');
            })
            .fail(function( data ) {
                ohSnap('Oh no! We were unable to send your message...', 'red');                
            })
    }

    // validate contact form
    $('#contact-form')
        .formValidation({
            // I am validating Bootstrap form
            framework: 'bootstrap',
            live: 'disabled',
            // List of fields and their validation rules!
            fields: {
                'contact_form[email]': {
                    verbose: false,
                    row: '.form-group',
                    validators: {
                        notEmpty: {
                            message: 'Your email is required'
                        },
                        emailAddress: {
                            message: "The email isn't valid"
                        },
                        remote: {
                            type: 'GET',
                            url: 'https://api.mailgun.net/v2/address/validate?callback=?',
                            crossDomain: true,
                            name: 'address',
                            data: {
                                // Registry a Mailgun account and get a free API key
                                // at https://mailgun.com/signup
                                api_key: 'pubkey-83a6-sl6j2m3daneyobi87b3-ksx3q29'
                            },
                            dataType: 'jsonp',
                            validKey: 'is_valid',
                            message: "The email isn't valid"
                        }
                    }
                },
                'contact_form[name]': {
                    verbose: false,
                    row: '.form-group',
                    validators: {
                        notEmpty: {
                            message: 'Please enter your name'
                        }
                    }
                },
                'contact_form[organization]': {
                    verbose: false,
                    row: '.form-group',
                    validators: {
                        notEmpty: {
                            message: 'Please enter your company'
                        }
                    }
                },
                'contact_form[message]': {
                    verbose: false,
                    row: '.form-group',
                    validators: {
                        notEmpty: {
                            message: 'Please enter a message'
                        }
                    }
                }
            }
        })
        .on('success.validator.fv', function(e, data) {
            if (data.field === 'contact_form[email]' && data.validator === 'remote') {
                var response = data.result;  // response is the result returned by MailGun API
                if (response.did_you_mean) {
                    // Update the message
                    data.element                    // The field element
                        .data('fv.messages')        // The message container
                        .find('[data-fv-validator="remote"][data-fv-for="contact_form[email]"]')
                        .html('Did you mean ' + response.did_you_mean + '?')
                        .show();
                }
            }
        })
        .on('err.validator.fv', function(e, data) {
            if (data.field === 'contact_form[email]' && data.validator === 'remote') {
                // We need to reset the error message
                data.element                // The field element
                    .data('fv.messages')    // The message container
                    .find('[data-fv-validator="remote"][data-fv-for="contact_form[email]"]')
                    .html("The email isn't valid")
                    .show();
            }            
        })
        .on('success.form.fv', function(e, data) {
            e.preventDefault;
            submit_contact_form($('#contact-form').serialize());
            $(this).trigger("reset");
            return false;
        });
        // validate contact form

    
     // validate text me form
    $('#tell-me-form')
        .formValidation({
            // I am validating Bootstrap form
            framework: 'bootstrap',
            live: 'disabled',
            // List of fields and their validation rules!
            fields: {
                'phone': {
                    row: '.form-group',
                    validators: {
                        callback: {
                            callback: function (value, validator, $field) {
                                if (telInput.intlTelInput("isValidNumber")) {
                                    return {
                                        valid: true,    // or false
                                        message: 'Valid number'
                                    }
                                } else {
                                    return {
                                        valid: false,    // or false
                                        message: 'Enter a valid number'
                                    }
                                }
                            }
                        }
                    }
                },
                'zip': {
                    verbose: false,
                    row: '.form-group',
                    validators: {
                        notEmpty: {
                            message: 'Please enter your zip code'
                        }
                    }
                }
            }
        })
        .on('success.form.fv', function(e, data) {
            e.preventDefault;
            var number = telInput.intlTelInput("getNumber"), zip = $('#zip').val();            
            var json = { "contact_form" : { "email" : "team@getrhombus.com", "message" : number + " - " + zip, "name" : "Text me"  } }
            submit_contact_form(json);
            $(this).trigger("reset");
            return false;
        });
        // validate text me form    

});


/* Page Loading */
$(window).load(function() {
  $(".loading").fadeOut(750);
})
;
